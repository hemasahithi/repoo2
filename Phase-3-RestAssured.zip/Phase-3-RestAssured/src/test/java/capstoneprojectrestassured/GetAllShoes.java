package capstoneprojectrestassured;



import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class GetAllShoes {
	@Test
	
	public void get_all_products()
	{
		
		RestAssured.given()
		.baseUri("http://localhost:9010")
		.basePath("/get-shoes")
		.when().get()
		.then().statusCode(200)
		.log().all();
	}
@Test
	public void get_all_users()
	{
		RestAssured.given()
		.baseUri("http://localhost:9010")
		.basePath("/get-users")
		.when().get()
		.then().statusCode(200)
		.log().all();
	}

    @Test
    
    public void postMethod() {

    }
}
