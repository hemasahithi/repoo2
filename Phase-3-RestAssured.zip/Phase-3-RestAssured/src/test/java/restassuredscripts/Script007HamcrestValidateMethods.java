package restassuredscripts;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
public class Script007HamcrestValidateMethods {
	
	//Hamcrest dependency has been added to your POM File
	//This dependency provides us many validation methods that help us to validate the response code
	//equalTo() Hamcrest method
	
	public void ValidateResponseBody() {
		
		String PMapikey="PMAK-6577e41154586e0031c5c7a8-081d9dcbf692875b1603cc71193a09964b";
		given().baseUri("https://api.postman.com")
		.basePath("/workspaces")
		.header("x-api-key",PMapikey)
		.when().get()
		.then().statusCode(200)
		
		
		.body("workspace[1].id",equalTo("c497fd27-7755-4fa5-bf2c-4f43c6824e3e"),
				"workspace[1].name",equalTo("Phase3Practice"),
				"workspaces[3].type", equalTo("personal"));
				}
	
	@Test(priority='2')
	public void ValidateResponseBody_equalTo() {
		
		
		given().baseUri("https://petstore.swagger.io")
		.basePath("/v2/user/Sahithi")
		.when().get()
		.then().statusCode(200)
		//fetch the response body and validate if response includes correct values or not
		
		.body("username", equalTo("Sahithi"),
			 ("firstName"),equalTo("Naga"),
			 ("lastName"),equalTo("Sahithi"),
			 ("email"),equalTo("sahi876@gmail.com"),
			 ("userStatus"),equalTo(1));
			 
			 		
	}
	@Test(priority='3')
	public void ValidateResponseBody_hasItems() {
		
	String PMapikey="PMAK-6577e41154586e0031c5c7a8-081d9dcbf692875b1603cc71193a09964b";
		
		given().baseUri("https://api.postman.com")
		.basePath("/workspaces")
		.header("x-api-key",PMapikey )
		.when().get()
		.then().statusCode(200)
		// fetch the response body and validate if response includes correct values or not
		
		.body("workspaces.name", hasItems("Phase3Practice", "My Workspace", "Workspace-1"),
			 "workspaces.type", hasItems("personal", "personal"));
		
		
	}

	

}
