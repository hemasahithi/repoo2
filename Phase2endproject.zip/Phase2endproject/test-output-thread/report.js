$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"8c9a200f-b263-48c0-975c-5f5d64e9a042","feature":"Test the starHealth page on Chrome Browser","scenario":"Validate the Star Health Buy Now flow","start":1701433524786,"group":1,"content":"","tags":"","end":1701433564672,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[#1,main,5,main]"}]);
});