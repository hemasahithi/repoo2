package restassuredscripts;
import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Script006PostmanAPIKey {
	@Test(priority='1')
	
	
	public void postmangetReq() {
		
		String PMapikey = "PMAK-6577e41154586e0031c5c7a8-081d9dcbf692875b1603cc71193a09964b";
		given().baseUri("https://api.postman.com").basePath("/workspaces")
		.header("x-api-key",PMapikey).when().get()
		.then().statusCode(200).log().all();
		
	}
	
@Test(priority='2')
	
	
	public void extract_value_response() {
		
		String PMapikey = "PMAK-6577e41154586e0031c5c7a8-081d9dcbf692875b1603cc71193a09964b";
	String responseoutput=given().baseUri("https://api.postman.com").basePath("/workspaces")
			.header("x-api-key",PMapikey).when().get()
			.then()
			.extract().path("x.workspaces[0].name"); //extract the name and save it in a string
	        System.out.println("The name of the workspace extracted is : " +responseoutput);
		
}

@Test(priority='3')


public void extract_response_JSONPath() {
	
	String PMapikey = "PMAK-6577e41154586e0031c5c7a8-081d9dcbf692875b1603cc71193a09964b";
Response res =given().baseUri("https://api.postman.com").basePath("/workspaces")
		.header("x-api-key",PMapikey).when().get()
		.then()
		.extract().response(); //extract the name and save it in a string
        JsonPath json = new JsonPath(res.asString());
        System.out.println(json.getString("workspaces[0]"));
	
}



}
