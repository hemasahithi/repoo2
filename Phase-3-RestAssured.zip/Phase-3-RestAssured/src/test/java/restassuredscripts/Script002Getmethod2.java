package restassuredscripts;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Script002Getmethod2 {
	@Test
	public void httpGetMethod() {
		Response res= RestAssured.get("https://reqres.in/api/users/3");
		
		System.out.println(res.getStatusCode());
		
		System.out.println(res.getBody().asPrettyString());
		System.out.println(res.getTime());
		System.out.println(res.getHeader("Content-Type"));
	}
	

}
