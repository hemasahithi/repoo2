package restassuredscripts;


import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Practicescript001 {
	@Test
	public void employees(){
		
Response res= RestAssured.get("https://dummy.restapiexample.com/employees");
		
		System.out.println(res.getStatusCode());
		
		System.out.println(res.getBody().asPrettyString());
		System.out.println(res.getTime());
		System.out.println(res.getHeader("Content-Type"));
		
		
	}

}
